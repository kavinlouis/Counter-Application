function addOne(){
    var count = document.getElementById("Display").innerHTML;
    count++;
    document.getElementById("Display").innerHTML = count;
}
function minusone(){ var count = document.getElementById("Display").innerHTML;
    count--; 
  
      document.getElementById("Display").innerHTML = count--;
}


function reset(){
    document.getElementById("Display").innerHTML = "0";
};